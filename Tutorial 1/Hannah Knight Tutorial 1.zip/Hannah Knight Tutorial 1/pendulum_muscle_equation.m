function thetadoubledot = pendulum_muscle_equation(t,theta,u1, u2) 
    
% nb: u1 is muscle activation of muscle 1 etc

% Muscle parameters
    a1 = 0.0436;
    a2 = 0.09;
    alpha = 0.0218;
    k_0 = 810.8;  
    k = 1621.6;
    damping_ratio = 0.26;
    m = 1;
    r=0.3;


    delta_0 = 2*damping_ratio*sqrt(m*k_0);
    delta = 2*damping_ratio*sqrt(m*k);
    l_0 = sqrt( a1^2+a2^2 - 2*a1*a2*cos(pi/2));
    l_1 = sqrt( a1^2+a2^2 - 2*a1*a2*cos(theta+(pi/2)));
    delta_l = (l_1 - l_0)/t;
    g = 9.81;
    
    k_total = (k_0 + k*u2);
    l_update = (l_0 + alpha*u2 -delta_l);
    d_total = (delta_0 + delta * sqrt(u2));

    mu = k_total*l_update - d_total*delta_l;

    torque = mu .* (sin( theta +( pi/2) )* a1) / ( l_1 );

    thetadoubledot = torque / m*(r^2);
  
end