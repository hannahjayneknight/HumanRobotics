function g = g(t_n)
    g = (t_n.^3) .* ( 6.*(t_n.^2) - 15.*t_n + 10);
end